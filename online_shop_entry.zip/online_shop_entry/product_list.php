<!DOCTYPE html>
<html lang="bg">
    <head>
        <meta charset="UTF-8">
        <title>Списък на продуктите</title>

        <style>
            body {
                font-family: Arial, sans-serif;
                background: white;
                }
            h1 {
                text-align: center;
                color: black;
            }
            table {
                border-collapse: collapse;
                width: 50%;
                margin: auto;
                background: #9B9A9C;
            }
            th, td {
                border: 1px solid;
                padding: 10px 15px;
                text-align: center;
            }
            th {
                border-width: 1px;
                border-color: black;
                background-color: #E21C20;
                color: white;
            }
            .buttons {
                text-align: center;
                margin-bottom: 20px;
            }
            .buttons a {
                text-decoration: none;
                color: white;
                padding: 10px 20px;
                margin: 0 10px;
                font-weight: bold
            }
            .add{
                background-color: #98E71C
            }
            .remove {
                background-color: #FF1E1C
            }
        </style>
    </head>
    <body>
    <h1>Списък на продуктите</h1>

    <div class="buttons">
        <a href="add_product.php" class="add">Добави продукт</a>
        <a href="remove_sell_product.php" class="remove">Премахни продукт</a>
    </div>
        <?php
            require 'db_connection.php';

            $sqlTotal = "SELECT SUM(price * quantity) AS total_value, SUM(quantity) AS total_quantity FROM products";
            $resultTotal = $dbConn->query($sqlTotal);

            if ($resultTotal && $resultTotal->num_rows > 0) {
                $rowTotal = $resultTotal->fetch_assoc();
                $totalValue = $rowTotal['total_value'];
                $totalQuantity = $rowTotal['total_quantity'];

                echo "<p style='text-align:center; font-weight:bold; font-size:18px;'>";
                echo "Общо количество: $totalQuantity бр. | Обща стойност: " . number_format($totalValue, 2, '.', '') . " лв.";
                echo "</p>";
            }

            $sql = "SELECT * FROM products";
            $result = $dbConn->query($sql);

            if ($result && $result->num_rows > 0) {
                echo "<table>";
                echo "<tr><th>Продукт</th><th>Цена (лв)</th><th>Количество</th></tr>";

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                    <td>{$row['name']}</td>
                    <td>" . number_format($row['price'], 2, '.', ''). "</td>
                    <td>{$row['quantity']}</td>
                    </tr>";
                }

                echo "</table>";
            } else {
                echo "<p style='text-align: center;'>Няма добавени продукти в магазина.</p>";
            }

            $dbConn->close();
        ?>
    </body>
</html>
