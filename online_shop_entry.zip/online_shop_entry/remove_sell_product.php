<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Управление на стоката</title>
        
        <style>
            body {
                font-family: Arial
            }
            input { 
                padding: 5px; margin: 5px 0; width: 20%;
            }
            button {
                padding: 5px; margin: 5px 0; width: 10%;
            }
            .buttons a{
                text-align: center;
                text-decoration: none;
                color: white;
                background-color: #AAAAAA;
                padding: 5px 20px;
                margin: 0 10px;
                display:inline-block;
                border:1px solid black;
            }
               
            
        </style>
    </head>
    <body>
        <h1 align="center">Управление на стоката</h1>
        
        <form action="" method="post" align="center">
             <h2>Премахване и продажба на продукти</h2>
             <label>Наименование на продукта: </label> <input type="text" name="name"/> <br>
             <label>Количество за премахване или продажба: </label><input type="text" name="quantity"/> <br>
             <button type="submit" name="remove">Премахни</button> <button type="submit" name="sell">Продай</button> <br>
             <div class="buttons">
                 <a href="product_list.php">Прегледай списък</a>
             </div>
        </form>
        
        <?php
            require 'db_connection.php';
            ob_start();

            if (isset($_POST['sell'])) {
                $name = trim($_POST['name']);
                $quantity = intval($_POST['quantity']);

                if ($name === '' || $quantity <= 0) {
                    echo "<p style='color:red; text-align:center;'>Моля въведете валидно име и количество.</p>";
                } else {
                    $sql = "SELECT id, quantity FROM products WHERE name = '$name'";
                    $result = mysqli_query($dbConn, $sql);

                    if ($result && mysqli_num_rows($result) > 0) {
                        $row = mysqli_fetch_assoc($result);
                        if ($row['quantity'] >= $quantity) {
                            $newQuantity = $row['quantity'] - $quantity;
                            $update = "UPDATE products SET quantity = $newQuantity WHERE id = " . $row['id'];
                            mysqli_query($dbConn, $update);
                            echo "<p style='color:green; text-align:center;'>Продажбата е успешна!</p>";
                        } else {
                            echo "<p style='color:red; text-align:center;'>Няма достатъчно наличност (Остават {$row['quantity']}).</p>";
                        }
                    } else {
                        echo "<p style='color:red; text-align:center;'>Продуктът не е намерен.</p>";
                    }
                }
            }

            if (isset($_POST['remove'])) {
                $name = trim($_POST['name']);
                $quantity = intval($_POST['quantity']);

                if ($name === '') {
                    echo "<p style='color:red; text-align:center;'>Моля въведете продукт и количество за премахване или продажба.</p>";
                } else if(is_numeric($name)){
                    echo "<p style='color:red; text-align:center;'>Моля въведете валиден продукт.</p>";
                } else {
                    $check = mysqli_query($dbConn, "SELECT id, quantity FROM products WHERE name = '$name'");
                    if ($check && mysqli_num_rows($check) > 0) {
                        $row = mysqli_fetch_assoc($check);
                        $currentQuantity = $row['quantity'];

                        if ($quantity < $currentQuantity) {
                            $newQuantity = $currentQuantity - $quantity;
                            mysqli_query($dbConn, "UPDATE products SET quantity = $newQuantity WHERE id = {$row['id']}");
                            echo "<p style='color:green; text-align:center;'>Премахнати са $quantity броя от '$name'.</p>";
                        } elseif ($quantity == $currentQuantity) {
                            mysqli_query($dbConn, "DELETE FROM products WHERE id = {$row['id']}");
                            echo "<p style='color:green; text-align:center;'>Цялата наличност от '$name' са премахнати.</p>";
                        } else {
                            echo "<p style='color:red; text-align:center;'>Няма достатъчно наличност. В момента има само $currentQuantity бр.</p>";
                        }
                    }
                }
            }
        ?>
    </body>
</html>
