<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $host = 'localhost';
            $dbUser = 'root';
            $dbPass = '';
            $dbName = 'online_shop';
            
                if (!$dbConn = mysqli_connect($host, $dbUser, $dbPass)) {
                  die('Не може да се осъществи връзка със сървъра.');
                }
                if (!mysqli_select_db($dbConn, $dbName)) {
                  die('Не може да се селектира базата от данни.');
                } 
                
            mysqli_query($dbConn, "SET NAMES 'UTF8'");
                $sql = "CREATE TABLE IF NOT EXISTS products (
                id INT NOT NULL AUTO_INCREMENT,
                name VARCHAR(30) DEFAULT NULL,
                price DOUBLE DEFAULT NULL,
                quantity INT DEFAULT NULL,
                PRIMARY KEY (id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
                        
                try {
                    $result = mysqli_query($dbConn, $sql);
                    } catch (Exception $e) {
                        echo ("Грешка при създаване на таблица: " . $e->getMessage());
                        echo "<br/>";
                    }
                if ($result) {
                        echo " ";
                }
        ?>
    </body>
</html>
