<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Управление на стока</title>
        
        <style>
            body {
                font-family: Arial
            }
            input { 
                padding: 5px; margin: 5px 0; width: 20%;
            }
            button {
                padding: 5px; margin: 5px 0; width: 10%;
            }
            .buttons a{
                text-align: center;
                text-decoration: none;
                color: white;
                background-color: #AAAAAA;
                padding: 5px 20px;
                margin: 0 10px;
                display:inline-block;
                border:1px solid black;
            } 
        </style>
    </head>
    <body>
        <h1 align="center">Управление на стоката</h1>
        
        <form action="" method="post" align="center">
         <h2>Добавяне на продукти</h2>
         <label>Наименование на продукта: </label> <input type="text" name="name"/> <br>
         <label>Цена на продукта: </label><input type="text" name="price"/> <br>
         <label>Количество: </label><input type="text" name="quantity"/> <br>
         <button type="submit" name="add_product">Добави</button> <br>
         <div class="buttons">
             <a href="product_list.php">Прегледай списък</a>
         </div>
        </form>
        
        <?php
        require 'db_connection.php';
        
        if (isset($_POST['add_product'])){
            $name = mysqli_real_escape_string($dbConn, ($_POST['name']));
            $price = doubleval($_POST['price']);
            $quantity = intval($_POST['quantity']);
            
            $sql = "SELECT id, quantity FROM products WHERE name = '$name'  AND price = $price";
            $result = mysqli_query($dbConn, $sql);
            
            if ($name === '' || $price === '' || $quantity === '') {
            echo "<p style='color:red;' align='center'>Моля, попълнете всички полета!</p>";
            exit;
            }

            if (is_numeric($name)) {
                echo "<p style='color:red;' align='center'>Името на продукта не може да бъде число!</p>";
                exit;
            }

            if (!is_numeric($price) || $price <= 0) {
                echo "<p style='color:red;' align='center'>Цената трябва да бъде положително число!</p>";
                exit;
            }

            if (!is_numeric($quantity) || $quantity <= 0) {
                echo "<p style='color:red;' align='center'>Количеството трябва да бъде положително число!</p>";
                exit;
            }
            
            if (mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $newQuantity = $row['quantity'] + $quantity;

                $update = "UPDATE products SET quantity = $newQuantity WHERE id = " . $row['id'];
                mysqli_query($dbConn, $update);

                echo "<p style='color:lightgreen;' align='center'>Продуктът вече съществува — количеството е увеличено!</p>";
            } else {
                $insert = "INSERT INTO products (name, price, quantity) VALUES ('$name', $price, $quantity)";
                if (mysqli_query($dbConn, $insert)) {
                echo "<p style='color:lightgreen; text-align:center;'>Продуктът е успешно добавен!</p>";
                } else {
                echo "<p style='color:red; text-align:center;'>Грешка при добавяне: " . mysqli_error($dbConn) . "</p>";
                }
            }
        }
        ?>
    </body>
</html>
